
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv('historical_sales_data.csv')

# Prepare features
data['Day'] = range(1, len(data)+1)

X = data[['Day']]
y = data['Sales']

# Train model
model = LinearRegression()
model.fit(X, y)

# Predict next 30 days
future_days = pd.DataFrame({'Day': range(len(data)+1, len(data)+31)})
predictions = model.predict(future_days)

# Save predictions
future_days['PredictedSales'] = predictions
future_days.to_csv('sales_predictions.csv', index=False)

print(future_days.head())

# Plot
plt.plot(data['Day'], y, label='Historical Sales')
plt.plot(future_days['Day'], predictions, label='Predicted Sales')
plt.legend()
plt.show()

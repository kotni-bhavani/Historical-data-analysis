
CREATE TABLE SalesData (
    Date DATE,
    Sales FLOAT,
    Customers INT,
    Profit FLOAT
);

-- Monthly Sales
SELECT MONTH(Date) AS Month, SUM(Sales) AS TotalSales
FROM SalesData
GROUP BY MONTH(Date);

-- Average Profit
SELECT AVG(Profit) AS AvgProfit
FROM SalesData;

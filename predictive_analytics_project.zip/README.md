
# Predictive Analytics Using Historical Data

## Overview
This project predicts future sales trends using historical business data with Python and Power BI.

## Features
- Historical data analysis
- Sales trend forecasting
- Linear regression prediction model
- Interactive Power BI dashboard

## Tools Used
- Power BI
- Python
- SQL
- Pandas
- Scikit-learn

## Files Included
- historical_sales_data.csv
- historical_sales_data.xlsx
- predictive_analytics.py
- predictive_queries.sql
- sales_trend.png

## Power BI Dashboard Suggestions
- KPI Cards
- Monthly Sales Trends
- Predicted vs Actual Sales
- Profit Analysis

## How to Run
1. Open Power BI
2. Import CSV dataset
3. Build visuals
4. Run Python file for forecasting

